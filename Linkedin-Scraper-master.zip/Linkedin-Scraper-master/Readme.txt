The Program can be executed by running Linkedin.py


The Program runs on Python 2.7 (64-bit)

The required Packages are:
1. requests
2. bs4 
3. re (Regular Expressions)
4. Pandas
5. GoogleApiClient
6. openpyxl ( Version 1.8.5)
7. fuzzy  , Link:  https://pypi.python.org/pypi/Fuzzy


->The program can be run on any IDE or from CommandLine

->In the program the Start_Index and the Last_index can be given, 
based on the index, the input will be read from the excel file and the output will 
written into the output file.

->The Program needs a Linkedin user-id and password. For testing purposes

username : jamesmurray7702213959@gmail.com
password : james123

-> The Program uses google Api client, with custom search . An API key is needed
to use it, which is already provided. 
->A cx value for the google custom search is needed, this custom search searches
the linkedin.com domain for the query

Execute the program and wait for it to finish .

Warning: The Free version of the google API only allows 100 requests per day.