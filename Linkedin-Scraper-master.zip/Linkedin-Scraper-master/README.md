# Linkedin-Scraper
This is a python program which scrapes linkedin information upto 98% accuracy using the google custom search API. It also uses pandas to read the search parameters from Excel Sheets and then scrape and write them back into another Excel Sheet.

The Packages needed are
1.Pandas
2.RE
3.Beautiful Soup 4
4.Requests
5.googleapiclient
6.openpyxl
7.fuzzy
8.Read the Readme.txt file on instructions.
